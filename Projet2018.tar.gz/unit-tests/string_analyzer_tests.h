

#ifndef __STRING_ANALYZER_TEST_H__
#define __STRING_ANALYZER_TEST_H__

#include "string_analyzer.h"
#include "bst_ops.h"
#include "print_tree.h"
#include "unit_test.h"

#ifdef __cplusplus
extern "C" {
#endif

void run_string_analyzer_test_unit(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* __STRING_ANALYZER_TEST_H__ */