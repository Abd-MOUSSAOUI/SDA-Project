

#ifndef __ORDERED_SET_TESTS_H__
#define __ORDERED_SET_TESTS_H__

#include <stdio.h>
#include <stdlib.h>
#include "unit_test.h"
#include "ordered_set.h"

#ifdef _cplusplus
extern "C" {
#endif

void run_ordered_set_test_unit(void);

#ifdef __cplusplus
}
#endif
#endif